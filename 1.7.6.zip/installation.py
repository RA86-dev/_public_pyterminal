import subprocess

libraries = [
    'urllib.request',
    'os',
    'webbrowser',
    'platform',
    'hashlib',
    'random',
    'getpass',
    'string',
    'subprocess',
    'speedtest',
    'art',
    'http.server',
    'cv2',
    'bcrypt',
    'socketserver',
    'matplotlib.pyplot',
    'threading',
    'PIL.Image',
    'io',
    'curses',
    'googletrans',
    'urllib.parse',
    'colorama',
    'requests',
    'wave',
    'numpy',
    'io.BytesIO',
    'http.server.SimpleHTTPRequestHandler',
    'selenium',
    'imageio',
    'moviepy',
    'ultralytics' 
]


def install_libraries(): 
    print('Installs: ' + str(libraries))
    print('REQUIRES IMPORTANT ADMINISTRATOR PERMISSION TO INSTALL LIBRARIES')

    confirm = input('Type CONFIRM to Confirm (OR TYPE UNINSTALL To uninstall):')
    if confirm == "CONFIRM":
        for package in libraries:
            subprocess.run(["pip3", "install", package])
        print('Thank You! You may officially read the readme.txt and continue the installation process. The Terminal in the file called index_pyt.py is now avaliable to use.')
        with open('index_pyt.py', 'r') as f:
            file_contents = f.read()
            exec(file_contents)
    else:
        print('Denied request to install libraries.')

install_libraries()
