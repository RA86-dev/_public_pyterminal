############
# * NAME:PyTerminal 
# * Version 1.5.2
# * Description: Does multiple functions like time and others.
# * Date Started: Sunday September 2nd 2023
# * SECOND UPDATE: Wed October 18th, 2023.
# * Officially Update Wed. Nov 15th, 2023.
################
from ultralytics import YOLO
import base64
import curses
import getpass
import getpass as g
import hashlib

# ONLOAD ANIMATION
import http.server
import io
import json as jx
import math
import os
import platform
import random
import socketserver
import ssl
import string
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.parse
import urllib.request
import wave
import webbrowser
from tkinter import ttk

import bcrypt
import cv2
#==)
#############
import imageio
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import PIL.Image
import requests
import speedtest
from art import text2art
from bs4 import BeautifulSoup
from colorama import Back, Fore, Style, init
from moviepy.editor import VideoClip
from moviepy.video.io.VideoFileClip import VideoFileClip
from selenium import webdriver
from tkinterweb import HtmlFrame


def display_readme():
    
    r = tk.Tk()
    r.title("README 1.0")
    """Displays the README file in a graphical user interface (GUI)."""

    
    text = tk.Text(r)
    text.pack(fill=tk.BOTH, expand=True)


    with open("README.md", "r") as f:
        readme_data = f.read()


    text.insert("end", readme_data)

    # Add a scrollbar to the text widget
    scrollbar = tk.Scrollbar(command=text.yview)
    text.config(yscrollcommand=scrollbar.set)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)


    r.mainloop()

from googletrans import Translator

translatorObject = Translator()
root = None
todo_list = []
from selenium import webdriver


def seleniumTest():
    print('IE does not work on Macbooks or anything but windows.')
   
    i = input('Type raw for browser (Edge, Chrome,  Firefox, IE for Internet Explorer, Safari (does not work on Windows)): ')
    if i.upper() == "EDGE":
        driver = webdriver.Edge()
    elif i.upper() == "CHROME":
        driver = webdriver.Chrome()
    elif i.upper() == "FIREFOX":
        driver = webdriver.Firefox()
    elif i.upper() == "IE" or i.upper == "INTERNET EXPLORER":
        driver = webdriver.Ie()
    elif i.upper() == "SAFARI":
        driver = webdriver.Safari()
    
   


    print("""
    Type a number in the List:
    1. Add Cookie
    2. Return to main function
    3. Fullscreen tab
    4. Delete All Cookies
    5. Visit Website:
    6. Create Cookie
    7.Print Page
    8.Screenshot Page
    9. Go Forward
    10. Go Back
    """)
    while True:
        r = int(input(' > '))
        try:
            if r == 1:
                name = input('Name Of Cookie: ')
                value = input('Value: ')
                driver.add_cookie({'name':str(name),'value':value})
            elif r == 2:
                elementId = input('Element Tag: ')
                driver.create_web_element(elementId)
            elif r == 3:
                driver.fullscreen_window()
            elif r == 4:
                driver.delete_all_cookies()
            elif r == 5:
                url = input('URL: ')
                driver.get(url)
            elif r == 6:
                nameOfCookie = input('Name: ')
                valueOfCookie = input('Value:')
                try:
                    driver.add_cookie({'name':nameOfCookie,'value':valueOfCookie})
                    print('sucessfully created cookie!')
                except Exception as e:
                    print('Error: '+ e) 
                

            elif r == 7:
                driver.print_page()
            elif r == 8:
                screenshot = driver.get_screenshot_as_png()
                nameofFile =input(
                    'File Name (No extension): '
                )
                filename = str(nameofFile + ".png")

                with open(filename, "wb") as f:
                    f.write(screenshot)
                    print('Sucessfully Wrote to file. Open the file called screenshot.png to open the file.')
            elif r == 9:
                driver.forward()
            elif r == 10:
                driver.back()
            elif r == 2:
                return
        except Exception as e:
            print('Error: ' + e)
            



def scrape_website():
    
    # Make a request to the website
    url = input('URL: ')
    response = requests.get(url=url)

    # Check if the request was successful
    if response.status_code == 200:
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract all links (a tags)
        links = soup.find_all('a')
        print("Links:")
        for link in links:
            print(link.get('href'))

        # Extract all text content
        text_content = soup.get_text()
        print("\nText Content:")
        print(text_content)

    else:
        print(f"Error: Unable to retrieve content from {url}")

import random
from http.server import SimpleHTTPRequestHandler
from io import BytesIO

import matplotlib.pyplot as plt
import numpy as np


def plot_wave(range_start, range_end, wave_type='sine'):
    x = np.linspace(range_start, range_end, 100)
    
    if wave_type == 'sine':
        y = np.sin(x)
    elif wave_type == 'cosine':
        y = np.cos(x)
    else:
        raise ValueError("Invalid wave type. Please choose 'sine' or 'cosine'.")

    plt.plot(x, y)
    plt.title(f'{wave_type.title()} Wave')
    plt.xlabel('x-axis')
    plt.ylabel('y-axis')
    plt.grid(True)
    plt.show()

def init_pyt():
    start = float(input("Enter the start of the range for x-axis: "))
    end = float(input("Enter the end of the range for x-axis: "))
    wave = input("Enter the type of wave (sine or cosine): ")

    # Call the function with user input parameters
    plot_wave(start, end,wave)

server_running = False
httpd = None
custom_html = None


def start_server():
    global server_running, httpd
    if not server_running:
        Handler = MyHandler
        PORT = int(input("Enter port: "))
        server_address = ("", PORT)
        httpd = socketserver.ThreadingTCPServer(server_address, Handler)
        server_thread = threading.Thread(target=httpd.serve_forever)
        server_thread.start()
        server_running = True
        print("Server Running on Port {}".format(PORT))

def stop_server():
    global server_running, httpd
    if server_running:
        httpd.shutdown()
        httpd.server_close()
        server_running = False
        print("Server Stopped")

class MyHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        if custom_html:
            self.wfile.write(custom_html.encode())
        else:
            self.wfile.write("No HTML file was sent for this purpose. To stop this program, press stop localhost and then import a new file, otherwise it will break.".encode())

    def log_message(self, format, *args):
        log_message = "[%s] %s\n" % (self.log_date_time_string(), format % args)
        print(log_message)

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        print("Received:", post_data)
        self.send_response(200)
        self.end_headers()
        response = BytesIO()
        response.write(b'getPostRequest')
        response.write(b'Received: ')
        response.write(post_data)
        print("Received Information from localhost Using: POST, received: " + str(post_data))

def open_custom_html():
    global custom_html
    file_path = input("Enter the path to the HTML file: ")
    if file_path:
        with open(file_path, "r") as file:
            custom_html = file.read()
        print("Custom HTML file loaded: {}".format(file_path))

def main():

    print("1. Start Server")
    print("2. Stop Server")
    print("3. Load Custom HTML")
    print("4. Quit Program")

    choice = input("Enter your choice: ")

    if choice == "1":
        start_server()
    elif choice == "2":
        stop_server()
    elif choice == "3":
        open_custom_html()
    elif choice == "4":
        if server_running:
            stop_server()
        print("Quitting Program")

    else:
        print("Invalid choice. Please select a valid option.")

def caesar_cipher(text, shift, action="encode"):
    result = ""
    for char in text:
        if char.isalpha():  # Process only alphabetic characters
            if char.islower():
                base = ord('a')
            else:
                base = ord('A')
            if action == "encode":
                result += chr((ord(char) - base + shift) % 26 + base)
            elif action == "decode":
                result += chr((ord(char) - base - shift) % 26 + base)
        else:
            result += char  # Preserve non-alphabetic characters
    return result



import random


def fetch_and_print_country_info():
    try:
        response = requests.get("https://restcountries.com/v3.1/all")
        response.raise_for_status()  # Raise an exception for 4xx and 5xx status codes
        data = response.json()

        print("Select a country to view information:")
        country_names = [country.get("name", {}).get("common", "N/A") for country in data]
        for name in country_names:
            print(name)


        selected_name = input("Enter the name of the country you want to view information for: ")
        os.system('clear')
        selected_country = None
        for country in data:
            commonName = country.get("name", {}).get("common", "N/A")

            if commonName == selected_name:
                selected_country = country
                break


        if selected_country:
            commonName = selected_country.get("name", {}).get("common", "N/A")
            officialName = selected_country.get("name", {}).get("official", "N/A")
            tlds = ", ".join(selected_country.get("tld", ["N/A"]))
            alpha2Code = selected_country.get("cca2", "N/A")
            alpha3Code = selected_country.get("cca3", "N/A")
            currencies = ", ".join(selected_country.get("currencies", {}).keys()) or "N/A"
            capitalCities = ", ".join(selected_country.get("capital", ["N/A"]))
            region = selected_country.get("region", "N/A")
            subregion = selected_country.get("subregion", "N/A")
            languages = ", ".join(selected_country.get("languages", {}).values()) or "N/A"
            borders = ", ".join(selected_country.get("borders", ["N/A"]))
            area = selected_country.get("area", "N/A")
            population = selected_country.get("population", "N/A")
            timezones = ", ".join(selected_country.get("timezones", ["N/A"]))
            latlng = selected_country.get("latlng")
            landlocked = selected_country.get("landlocked")
            flagPng = selected_country.get("flags", {}).get("png", "")
            flagSvg = selected_country.get("flags", {}).get("svg", "")
            flagAlt = selected_country.get("flags", {}).get("alt", "Flag information not available")
            coatOfArmsPNG = selected_country.get("coatOfArms", {}).get("png", "")
            coatOfArmsSVG = selected_country.get("coatOfArms", {}).get("svg", "")
            maps = selected_country.get("maps", {}).get("googleMaps", "N/A")
            maps2 = selected_country.get("maps", {}).get("openStreetMaps", "N/A")
            isIndependent = selected_country.get("independent")
            isUnitedNationsMember = selected_country.get("unMember")
            os.system('clear')
            print("Country Information:")
            print(f"Common Name: {commonName}")
            print(f"Official Name: {officialName}")
            print(f"TLDs: {tlds}")
            print(f"Alpha-2 Code: {alpha2Code}")
            print(f"Alpha-3 Code: {alpha3Code}")
            print(f"Currencies: {currencies}")
            print(f"Capital City(s): {capitalCities}")
            print(f"Region: {region}")
            print(f"Subregion: {subregion}")
            print(f"Languages: {languages}")
            print(f"Borders: {borders}")
            print(f"Area: {area} sq km")
            print(f"Population: {population}")
            print(f"Timezones: {timezones}")
            print(f"Latitude and Longitude: {latlng}")
            print(f"Is United Nations Member (Not including non-member observers): {isUnitedNationsMember}")
            print(f"Independent: {isIndependent}")
            print(f"Landlocked: {landlocked}")
            print(f"Maps Link (Google Maps): {maps}")
            print(f"Maps Link (Open Street Maps): {maps2}")
            print("\nFlag:")
            print(f"Flag PNG: {flagPng}")
            print(f"Flag SVG: {flagSvg}")
            print("Flag Alt: " + flagAlt)
            print("\nCoat Of Arms:")
            print(f"Coat Of Arms PNG: {coatOfArmsPNG}")
            print(f"Coat Of Arms SVG: {coatOfArmsSVG}")

        else:
            print("Country not found.")

    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch country data from the API: {e}")



   


todo_list = []
def add_task(task):
        todo_list.append(task)

def list_tasks():
    for i, task in enumerate(todo_list, start=1):
        print(f"{i}. {task}")

def remove_task(task_index):
    if 1 <= task_index <= len(todo_list):
        del todo_list[task_index - 1]
    else:
        print("Invalid task index")


def password_strength(password):
    length_ok = len(password) >= 8
    contains_lowercase = any(char.islower() for char in password)
    contains_uppercase = any(char.isupper() for char in password)
    contains_digit = any(char.isdigit() for char in password)
    contains_special = any(char in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/" for char in password)

    if length_ok and contains_lowercase and contains_uppercase and contains_digit and contains_special:
        return "Strong"
    elif length_ok and (contains_lowercase or contains_uppercase) and contains_digit:
        return "Moderate"
    else:
        return "Weak"



def salt_password(password):
    # Generate a salt using bcrypt
    salt = bcrypt.gensalt()
    
    # Append the salt to the password
    salted_password = str(password) + str(salt.decode('utf-8'))
    
    # Hash the salted password using bcrypt
    hashed = bcrypt.hashpw(salted_password.encode('utf-8'), salt)
    
    # Convert the hashed bytes to a UTF-8 encoded string for storage or printing
    hashed_password = hashed.decode('utf-8')
    
    return hashed_password


print('Finished Loading! Thank you for using PyTerminal!')
time.sleep(1)
timex = time.asctime()
os.system('clear')
ascii_art = '''
                         I8                                                                          ,dPYb,
                         I8                                                                          IP'`Yb
                      88888888                                        gg                             I8  8I
                         I8                                           ""                             I8  8'
 gg,gggg,    gg     gg   I8    ,ggg,    ,gggggg,   ,ggg,,ggg,,ggg,    gg    ,ggg,,ggg,     ,gggg,gg  I8 dP 
 I8P"  "Yb   I8     8I   I8   i8" "8i   dP""""8I  ,8" "8P" "8P" "8,   88   ,8" "8P" "8,   dP"  "Y8I  I8dP  
 I8'    ,8i  I8,   ,8I  ,I8,  I8, ,8I  ,8'    8I  I8   8I   8I   8I   88   I8   8I   8I  i8'    ,8I  I8P   
,I8 _  ,d8' ,d8b, ,d8I ,d88b, `YbadP' ,dP     Y8,,dP   8I   8I   Yb,_,88,_,dP   8I   Yb,,d8,   ,d8b,,d8b,_ 
PI8 YY88888PP""Y88P"8888P""Y8888P"Y8888P      `Y88P'   8I   8I   `Y88P""Y88P'   8I   `Y8P"Y8888P"`Y88P'"Y88
 I8               ,d8I'                                                                                    
 I8             ,dP'8I                                                                                     
 I8            ,8"  8I                                                                                     
 I8            I8   8I                                                                                     
 I8            `8, ,8I                                                                                     
 I8             `Y8P"  
'''
print(ascii_art)
print(f"Time: {timex}")
def search_recipe(search_term):
    # Define the URL for the MealDB API
    url = "https://www.themealdb.com/api/json/v1/1/search.php"

    # Create a dictionary with the query parameters
    params = {"s": search_term}

    # Send an HTTP GET request to the AP
    response = requests.get(url, params=params)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the JSON response
        data = response.json()

        # Check if there are any recipes found
        if data['meals'] is not None:
            for meal in data['meals']:
                # Print the details of each recipe
                print("Recipe Name: " + meal['strMeal'])
                print("Category: " + meal['strCategory'])
                print("Instructions: " + meal['strInstructions'])
                print("Ingredients:")
                for i in range(1, 21):
                    ingredient = meal.get(f'strIngredient{i}')
                    measure = meal.get(f'strMeasure{i}')
                    if ingredient and measure:
                        print(f"{measure.strip()} {ingredient.strip()}")
                print("\n")
        else:
            print("No recipes found for your search term.")
    else:
        print("Failed to retrieve data from the API.")




def askAndCompute():
    
    inx = input(' > ')
    return inx

def detect(c):
    
    if c == "version":
        print('1.7.6 --version task')




        
    elif c == "time":
        x = time.asctime()
        print(x)
    elif c.startswith("runPyFunction"):
        inputx = c[len("runPyFunction "):]
        try:
            exec(inputx)
        except Exception as e:
            print(f"Error: {e}")
    elif c == "calculator":
        
        print("Select operation:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exponentiation")
        print("6. Square Root")
        print("7. Trigonometric Functions")

        choice = input("Enter choice (1/2/3/4/5/6/7): ")

        if choice in ('1', '2', '3', '4'):
            num1 = float(input("Enter first number: "))
            num2 = float(input("Enter second number: "))

            if choice == '1':
                result = num1 + num2
                print(f"{num1} + {num2} = {result}")
            elif choice == '2':
                result = num1 - num2
                print(f"{num1} - {num2} = {result}")
            elif choice == '3':
                result = num1 * num2
                print(f"{num1} * {num2} = {result}")
            elif choice == '4':
                if num2 != 0:
                    result = num1 / num2
                    print(f"{num1} / {num2} = {result}")
                else:
                    print("Cannot divide by zero")
        elif choice == '5':
            num1 = float(input("Enter base: "))
            num2 = float(input("Enter exponent: "))
            result = num1 ** num2
            print(f"{num1} ** {num2} = {result}")
        elif choice == '6':
            num = float(input("Enter number: "))
            if num >= 0:
                result = math.sqrt(num)
                print(f"Square root of {num} = {result}")
            else:
                print("Cannot calculate square root of a negative number")
        elif choice == '7':
            angle = float(input("Enter angle in degrees: "))
            radian = math.radians(angle)
            print("Select trigonometric function:")
            print("a. Sine")
            print("b. Cosine")
            print("c. Tangent")
            trig_choice = input("Enter choice (a/b/c): ")
        if trig_choice in ('a', 'b', 'c'):
                if trig_choice == 'a':
                    result = math.sin(radian)
                    print(f"Sine({angle} degrees) = {result}")
                elif trig_choice == 'b':
                    result = math.cos(radian)
                    print(f"Cosine({angle} degrees) = {result}")
                elif trig_choice == 'c':
                    if abs(angle % 180) != 90:
                        result = math.tan(radian)
                        print(f"Tangent({angle} degrees) = {result}")
                    else:
                        print("Tangent is undefined for 90 and 270 degrees")
                else:
                    print("Invalid Input")
        else:
            print("Invalid Input")

    elif c == "install_libraries":
            i = str(input('Install Library Name: '))
            subprocess.run(["pip3", "install", i])
    elif c == "searchArtChicago":
        limitToHowMany = int(input('How Many artworks to pull: '))

        url = "https://api.artic.edu/api/v1/artworks"
        params = {'limit': limitToHowMany}  # Adjust the limit based on your needs
        all_artworks = []


        response = requests.get(url, params=params)

        if response.status_code == 200:
            data = response.json()
            artworks = data.get('data', [])


            all_artworks.extend(artworks)
            url = data.get('pagination', {}).get('next_url')
        else:
            print(f"Error: {response.status_code}")



        for artwork in all_artworks:
            print("Title:", artwork.get("title", "N/A"))
            print("Artist:", artwork.get("artist_display", "N/A"))
            print("Date:", artwork.get("date_display", "N/A"))
            print("Medium:", artwork.get("medium_display", "N/A"))
            print("Dimensions:", artwork.get("dimensions", "N/A"))
            print("Credit Line:", artwork.get("credit_line", "N/A"))
            print("===")

    elif c == "searchCrop":
        input_crop_name = input('Crop Name:')
        base_url = 'https://openfarm.cc/api/v1/crops'
        url = f'{base_url}/{input_crop_name}'
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            crop_data = data.get('data', {})
            crop_attributes = crop_data.get('attributes', {})
            print("Crop Name:", crop_attributes.get('name'))
            print("Binomial Name:", crop_attributes.get('binomial_name'))
            print("Common Names:", ', '.join(crop_attributes.get('common_names', [])))
            print("Description:", crop_attributes.get('description'))
            print("Sun Requirements:", crop_attributes.get('sun_requirements'))
            print("Sowing Method:", crop_attributes.get('sowing_method'))
            print("Spread:", crop_attributes.get('spread'))
            print("Row Spacing:", crop_attributes.get('row_spacing'))
            print("Height:", crop_attributes.get('height'))
            print("Main Image Path:", crop_attributes.get('main_image_path'))
        else:
            print(f'Error: {response.status_code}, {response.text}')
    
    
    elif c == "CTF":
        i = input('Input Celsius: ' )
        l = (float(i)*9/5) + 32
        print(l)
    elif c == "FTC":
        #(32°F − 32) × 5/9 = 0°C
        n = input('Farenheit INPUT: ')
        l = float(n) - 32 * 9/5 
        print(l)
    elif c == "ran":
        print('Must be integer')
        l = int(input('MAX: '))
        lx = int(input('MIN: '))
        print(random.randint(l,lx))
    elif c == "sys_info":
            print("System Information:")
            print(f"Operating System: {platform.system()} {platform.release()}")
            print(f"Machine: {platform.machine()}")
            print(f"Processor: {platform.processor()}")
            print(f"Python Version: {platform.python_version()}")
            print(f"Current Directory: {os.getcwd()}")
    elif c == "redir":
        l = input('Enter Query: ')
        webbrowser.open('https://www.google.com/search?q=' + l)
    elif c == "list_file":
        files = os.listdir()
        for file in files:
            print(file)
    elif c == "salt_pas":
        print('Type the Non-salted Password:')
        i =input('> ')

        #Hash the password
        
        h = salt_password(i)
        print(h)

    elif c == "//division":
        x = int(input('First INP: '))
        z = int(input('Second INP: '))
        print(x//z)
    elif c == "show_img":
        file_link = input("Please enter the link to the image file: ")

        image = cv2.imread(file_link)

        if image is not None:
            option = input("Do you want to display the image in greyscale? (yes/no): ")

            if option.lower() == 'yes':
                gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                cv2.imshow('Grayscale Image', gray_image)
            else:
                cv2.imshow('Original Image', image)

            cv2.waitKey(0)
            cv2.destroyAllWindows()
        else:
            print("Failed to load the image. Please check the link or file path.")
    elif c == "logoShow":
        print('Press Q to quit.')

        image = cv2.imread("super.png")

        if image is not None:
            
                
            cv2.imshow('Logo', image)

            cv2.waitKey(0)
            cv2.destroyAllWindows()
    elif c == "appendFile":
        i = input('File Name along with extension: ')
        with open(i, 'a') as f:
            i = input('Write Text: ')
            f.write(i)
    elif c == "show_video":
        video_capture = cv2.VideoCapture(0)  # Change the argument if using a different video source
        greyscale_detect = input("Do you want greyscale? (yes/no): ").lower()  # Assuming 'greyscale_detect' is user input

        while True:
            ret, frame = video_capture.read()
            if not ret:
                break
        
            if greyscale_detect == "no":
                cv2.imshow('Video Feed', frame)
            else:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                cv2.imshow("Camera in Greyscale", gray)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        video_capture.release()
        cv2.destroyAllWindows()
    elif c == "run_py":
        i = input('Filename: ')
        with open(i, 'r') as f:
            file_contents = f.read()
            exec(file_contents)
    elif c == "readFile":
        i = input('Filename: ')
        with open(i, 'r') as f:
            file_contents = f.read()
            print('Text File: ' + file_contents)
    elif c == "writeFile":
        i = input('Filename (.txt, .py, any file extension): ')
        text = input('Write Text: ')
        with open(i, 'w') as f:
            f.write(text)
    elif c == "TIMER":
        r = int(input('Seconds :'))
        for remaning in range(r,0 ,-1):
            minutes,seconds = divmod(remaning,60)
            print(f"Time Remaining: {minutes:02d}: {seconds:02d}",end='\r')
            time.sleep(1)
        print('Complete!                              ')
    elif c == "SHA256HASH":
        i = input('Input Value: ')
        has_obj = hashlib.new("sha256")     
        has_obj.update(i.encode())
        hash_value = has_obj.hexdigest()
        print(f'RESULT! {hash_value}')
    
    elif c == "quitProgram":
        quit()
    elif c == "password_strength":
        lxbv = getpass.getpass('Password to check: ')
        password_strength_2 = password_strength(lxbv)
        print(f'Password strength {password_strength_2}')
    elif c == "list_tasks":
        for i,task in enumerate(todo_list,start=1):
            print(f"{i}. {task}") 
    elif c == "remove_tasks":
        list_tasks()
        xMx = int(input('Task to remove (Give a number):'))
        remove_task(xMx)
    
  

    elif c == "generateart":
       
        text = input("Enter the text you want to convert to ASCII art: ")
        font = input("""Enter the font style ,The examples are: "block"
        "caligraphy"
        "doh"
        "epic"
        "fender"
        "isometric1"
        "letters"
        "alligator"
        "dotmatrix"
        "big"
        "small"
        "smslant": """)
    
        ascii_art = text2art(text, font=font)
        print(ascii_art)

    elif c == "add_tasks":
        zmxc = input('Name Of Task : \n')
        add_task(zmxc)
    elif c == "weatherwttr":
        nate = input('Request Location: \n > ')
        city = urllib.parse.quote(nate)

        lang = "en"

        def fetch_data(url, label):
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    data = response.text
                    print(f'{label}: {data}')
                else:
                    print(f'Failed to fetch {label} data.')
            except Exception as e:
                print(f'Failed to fetch {label} data. Error Index: {e}')

        def fetchCondition():
            url = f"https://wttr.in/{city}?format=%C&lang={lang}"
            fetch_data(url, 'Condition')

        def fetchTemperature():
            url = f"https://wttr.in/{city}?format=%t&lang={lang}"
            fetch_data(url, 'Temperature')

        def fetchHumidity():
            url = f"https://wttr.in/{city}?format=%h&lang={lang}"
            fetch_data(url, 'Humidity')

        def fetchWind():
            url = f"https://wttr.in/{city}?format=%w&lang={lang}"
            fetch_data(url, 'Wind')

        def fetchPrecipitation():
            url = f"https://wttr.in/{city}?format=%f&lang={lang}"
            fetch_data(url, 'Precipitation')

        def fetchPressure():
            url = f"httpswttr.in/{city}?format=%P&lang={lang}"
            fetch_data(url, 'Pressure')

        def fetchSunrise():
            url = f"https://wttr.in/{city}?format=%S&lang={lang}"
            fetch_data(url, 'Sunrise')

        def fetchSunset():
            url = f"https://wttr.in/{city}?format=%s&lang={lang}"
            fetch_data(url, 'Sunset')

        def fetchUV():
            url = f"https://wttr.in/{city}?format=%u&lang={lang}"
            fetch_data(url, 'Ultraviolet Index')

        def fetchfeelslike():
            url = f"https://wttr.in/{city}?format=%f&lang={lang}"
            fetch_data(url, 'Feels Like (Temperature)')

        # Call the functions to fetch and print the data
        fetchCondition()
        fetchTemperature()
        fetchHumidity()
        fetchWind()
        fetchPrecipitation()
        fetchPressure()
        fetchSunrise()
        fetchSunset()
        fetchUV()
        fetchfeelslike()


    elif c == "iss_location":
        requete = requests.get('http://api.open-notify.org/iss-now.json')
        x = requete.json()
        print('Response:')

        longitude = x["iss_position"]["longitude"]
        print('Longitude: ' + longitude)
        latitude = x["iss_position"]["latitude"]
        print('Latitude: ' + latitude)
    elif c=="joke_generator":
        requedx  = requests.get('https://riddles-api.vercel.app/random')
        req = requedx.json()
        joke = req["riddle"]
        answer = req["answer"]
        print('Joke: ' + joke)
        insert = input('input ans to complete (Case-sensitive), or type "quit" to end: \n > ')
        if (insert == "ans"):
            print('Answer: ' + answer)
        if (insert == "quit"):
            return;
    elif c=="setColor":
        print('Colors Avaliable to use (case-sensitive) BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE.')
        inputx = input('> ')
        text = input('Input Text:')
        if (inputx == "BLACK"):
            print(Fore.BLACK + text) 
            print(Fore.RESET +'')
        
        if (inputx == "RED"):
            print(Fore.RED + text)
            print(Fore.RESET +'')
        
        if (inputx == "GREEN"):
            print(Fore.GREEN + text)

            print(Fore.RESET +'')
        if (inputx == "YELLOW"):
            print(Fore.YELLOW + text)
            print(Fore.RESET +'')
        
        if (inputx == "BLUE"):
            print(Fore.BLUE + text)
            print(Fore.RESET + "")

        
        if (inputx == "MAGENTA"):
            print(Fore.MAGENTA + text)
            print(Fore.RESET +'')
        

        if (inputx == "CYAN"):
            print(Fore.CYAN + text)
            print(Fore.RESET +'')
        
        if (inputx == "WHITE"):
            print(Fore.WHITE + text)

            print(Fore.RESET +'')
  
    elif c == "googletrans":

        textToTranslate = input('Input text:\n > ')
        toLanguageCode = input('Input Destination Language Code:\n > ')
        detected_language = translatorObject.detect(textToTranslate).lang

        result = translatorObject.translate(textToTranslate, dest=toLanguageCode, src=detected_language)

        print("Translated text:", result.text)  # Translated text
        print("Source language:", result.src)   # Source language
        print("Destination language:", toLanguageCode)  # Destination language

    elif c == "webbrow_search":
        inx = input('HTTP: ')
        webbrowser.open(inx)
    elif c == "detectLang":
        textx = str(input('Input text:\n > '))
        x = translatorObject.detect(textx).lang
        print('Detected Language: ' + str(x))
    elif c == "matplotlib_gen":
        init_pyt()
    elif c == "functions":
        display_readme()
    elif c=="gtn":
        m = random.randint(1,100)
        print('Guess the number!')
        ans = input('> ')
        while True:
            ans = int(input('> '))
            if ans != m:
                if ans > m:
                    print('Lower!')
                if ans < m:
                    print('Higher')
                
            else:
                if ans == m:
                    print('Correct!')
                    break
                break
           



    elif c == "noteManager":
        xcm = input('Choose an option:\n1. View Notes\n2. Create Notes\n')

        if xcm == "1":
            """
            View all notes stored in the text file.
            """
            try:
                with open("notes.txt", "r") as file:
                    notes = file.read()
                    if notes:
                        print("Your notes:\n")
                        print(notes)
                    else:
                        print("No notes found.")
            except FileNotFoundError:
                print("No notes found.")
        elif xcm == "2":
           
            title = input("Enter a title for your note: ")
            content = input("Enter the content of your note: ")

            with open("notes.txt", "a") as file:
                file.write(f"Title: {title}\nContent: {content}\n\n")
            print("Note saved successfully.")
        
    elif c=="country":
        fetch_and_print_country_info()  
    elif c == "clear":

        os.system('clear')
    elif c=="caesar_cipher_enc":
        print(caesar_cipher(str(input('Text: \n > ')),int(input('Shift: \n > ')),action="encode"))
    elif c=="caesar_cipher_dec":
        print(caesar_cipher(str(input('Decode Text: \n > ')),int(input('Shift: \n > ')),action="decode"))

    elif c=="":
        os.system('clear')
    elif c == "ipnetwork":
        try:
            response = requests.get('https://ipapi.co/json')
            response.raise_for_status()
            data = response.json()

            ipx = data.get('ip', 'N/A')
            network = data.get('network', 'N/A')
            region = data.get('region', 'N/A')
            organization = data.get('org','N/A')


            print('IP: ' + ipx + '\nNetwork: ' + network + '\nRegion: ' + region + '\n Organization: ' + organization)

        except requests.exceptions.RequestException as e:
            print('Failed to fetch IP information:', e)
    elif c=="themealsearch":
        dx = input('meal search: \n > ')
        search_recipe(dx)
    elif c=="manualFetch":
        manualFetchLink = input('Fetch Link: \n > ')
        xm = requests.get(manualFetchLink)
        jsonManualFetch = xm.json()
        print('Manual JSON: ' + str(jsonManualFetch))
    elif c=="localhost":
        print('Please first load a custom html.')
        main()
    elif c == "refresh":
        timex = time.asctime()
        os.system('clear')
        print(f"Time: {timex}")
    elif c == "createQRCode":
        data = input('Input a String:')
        generatedURL = f"http://api.qrserver.com/v1/create-qr-code/?data={data}!&size=100x100"
        webbrowser.open(generatedURL)
    elif c == "webdriver":
        seleniumTest()
        
    
    elif c == "randomFood":
        urlForTheMealDB = "https://www.themealdb.com/api/json/v1/1/random.php"
        x = requests.get(urlForTheMealDB)
        z = x.json()
        mealInfo = z["meals"][0]  # Access the first item in the "meals" list

        mealStr = mealInfo["strMeal"]
        category = mealInfo["strCategory"]
        instructions = mealInfo["strInstructions"]
        area = mealInfo["strArea"]
        mealThumb = mealInfo["strMealThumb"]
        mealSource = mealInfo["strSource"]
        mealYoutube = mealInfo["strYoutube"]

        print('Meal: ' + str(mealStr))
        print('Category: ' + str(category))
        print('Instructions: ' + str(instructions))
        print('Area Created: ' + str(area))
        print('Meal Thumbnail: ' + str(mealThumb))
        print('Meal Source: ' + str(mealSource))
        print('YouTube Link: ' + str(mealYoutube))
    elif c == "pymov":
        def create_custom_video(output_file, width, height, duration, fps, background_color=(255, 255, 255), shape_color=(0, 0, 255)):
            # Function to generate frames
            def make_frame(t):
                frame = np.ones((height, width, 3), dtype=np.uint8) * background_color

                # Calculate position based on a bouncing effect
                bounce_duration = 2.0  # Time for one full bounce (up and down)
                t_bounce = t % bounce_duration  # Adjust time for bouncing effect

                # Use a quadratic function for the bouncing effect
                max_bounce_height = height // 3
                y = int(max_bounce_height * (1 - (t_bounce / bounce_duration - 0.5) ** 2))

                # Move from left to right
                x = int(t / duration * width)
                if x == width or x == 0:  # Bounce back when reaching the edges
                    x = width if x == 0 else 0

                # Create a circle and draw it on the frame
                radius = 20
                circle_points = np.array([[x, y]])
                frame[y - radius:y + radius, x - radius:x + radius] = shape_color

                return frame

            video_clip = VideoClip(make_frame, duration=duration)

            video_clip.write_videofile(output_file, fps=fps, codec='libx264')

        output_filename = input('Output Filename: (INCLUDE .MP4) ')
        video_width = int(input('Width of Video: '))
        video_height = int(input('Height of Video: '))
        video_duration = int(input('Video Duration (seconds): '))
        video_fps = int(input('FPS: '))
        background_colorr = int(input('Background Color (R):'))
        background_colorg = int(input('Background Color (G):'))
        background_colorb = int(input('Background Color (B):'))
        shape_colorr = int(input('Circle Color (R):'))
        shape_colorg = int(input('Circle Color (G):'))
        shape_colorb = int(input('Circle Color (B):'))
        create_custom_video(output_filename,video_width,video_height,video_duration,video_fps,background_color=(background_colorr, background_colorg, background_colorb),shape_color=(shape_colorr, shape_colorg, shape_colorb))



    elif c == "notepad":
        

        def main(stdscr):
            curses.curs_set(1)  # Show cursor
            stdscr.addstr(0, 0, "Use arrow keys to navigate. Press F2 to save and F10 to exit.")

            current_row = 2
            current_col = 1
            content = []

            while True:
                stdscr.move(current_row, current_col)
                key = stdscr.getch()

                if key == curses.KEY_F2:
                    file_name = input("Enter a file name to save: ")
                    with open(file_name, 'w') as file:
                        file.write('\n'.join(content))
                    stdscr.addstr(0, 0, f"File saved as {file_name}")
                    stdscr.clrtoeol()  # Clear the line
                    stdscr.refresh()
                elif key == curses.KEY_F10:
                    break
                elif key == curses.KEY_DOWN:
                    current_row = min(current_row + 1, curses.LINES - 1)
                elif key == curses.KEY_UP:
                    current_row = max(current_row - 1, 1)
                elif key == curses.KEY_LEFT:
                    current_col = max(current_col - 1, 0)
                elif key == curses.KEY_RIGHT:
                    current_col = min(current_col + 1, curses.COLS - 1)
                else:
                    content_row = current_row - 1  # Adjust for 0-based index
                    if len(content) < content_row:
                        content.extend([""] * (content_row - len(content) + 1))
                    if len(content[content_row - 1]) < current_col:
                        content[content_row - 1] += " " * (current_col - len(content[content_row - 1]))
                    content[content_row - 1] = content[content_row - 1][:current_col] + chr(key) + content[content_row - 1][current_col:]
                    current_col += 1

                stdscr.clear()  # Clear the screen (will cause flickering)
                for idx, line in enumerate(content, 1):
                    stdscr.addstr(idx, 0, line)

            curses.endwin()

        curses.wrapper(main)

        print('\n')
 







    elif c == "track_face":

        # Load the pre-trained Haar Cascade face detection model
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

        # Access the default webcam (usually index 0)
        cap = cv2.VideoCapture(0)

        while True:
            # Read each frame from the webcam
            ret, frame = cap.read()

            # Convert the frame to grayscale for face detection
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Detect faces in the frame
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=25)

            # Draw rectangles around the detected faces
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 3)

            # Display the frame with detected faces
            cv2.imshow('Face Tracking', frame)

            # Exit the loop if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    # Release the capture and destroy windows
        cap.release()
        cv2.destroyAllWindows()

    elif c == "searchHistory":
        month = input("Enter the month: ")
        day = input("Enter the day: ")
        keyword = input("Enter the keyword: ").strip()

        api_url = f'https://history.muffinlabs.com/date/{month}/{day}'
        response = requests.get(api_url)
        data = response.json()

        if not data.get('data') or not data['data'].get('Events') or len(data['data']['Events']) == 0:
            print("No events found for the given date and keyword.")
            return


        events = [event for event in data['data']['Events'] if keyword.lower() in event['text'].lower()]
        births = [event for event in events if event.get('type') == "birth"]
        deaths = [event for event in events if event.get('type') == "death"]

        if not events and not births and not deaths:
            print("No matching events, births, or deaths found for the given keyword.")


        if events:
            print("Events:")
            for event in events:
                  print(f"{event['year']}: {event['text']}")
                  if event.get('links'):
                      for link in event['links']:
                         print(f"  - {link['title']}: {link['link']}")

        if births:
            print("Births:")
            for event in births:
                print(f"{event['year']}: {event['text']}")
                if event.get('links'):
                    for link in event['links']:
                        print(f"  - {link['title']}: {link['link']}")

        if deaths:
            print("Deaths:")
            for event in deaths:
                print(f"{event['year']}: {event['text']}")
                if event.get('links'):
                    for link in event['links']:
                        print(f"  - {link['title']}: {link['link']}")
    elif c == "generate_color":

        # Generate random values for red, green, and blue components
        red = random.randint(0, 255)
        green = random.randint(0, 255)
        blue = random.randint(0, 255)

        # Convert the decimal values to hexadecimal and format as a color code
        color_code = '#{:02x}{:02x}{:02x}'.format(red, green, blue)

        print(color_code)
    elif c == "ascii85_encode":
        t = input('Text to Encode: ')
        m = base64.a85encode(t.encode('utf-8')).decode('utf-8')
        print(f"Result: {m}")
    elif c=="ascii85_decode":
        i = input('Text to Decode: ')
        r = base64.a85decode(i).decode('utf-8')
        print(f"Result: {r}")
    elif c == "speedtest-client":


        def run_speedtest():
            # Create a Speedtest object
            st = speedtest.Speedtest()

            # Find the closest server
            st.get_best_server()

            # Perform a speed test
            download_speed = st.download() / 1024 / 1024  # Convert to Mbps
            upload_speed = st.upload() / 1024 / 1024  # Convert to Mbps
            ping = st.results.ping

            return {
                "ping": f"${round(ping)} ms" ,
                "download_speed": f"{round(download_speed)} Mbps",
                "upload_speed": f"{round(upload_speed)} Mbps"
            }
        print('This Might take a second...')
        x = run_speedtest()

        print(f"""
        Ping: {x["ping"]} 
        Download Speed: {x["download_speed"]} 
        Upload Speed: {x["upload_speed"]} 

        """)

    elif c=="quit":
        
        quit()
    elif c=="youtube":
        p = input('Input Search Query: \n > ')
        webbrowser.open(f"https://www.youtube.com/results?search_query={p}")
    elif c == "word_splitter":
        i = input('Sentence (To split into words): \n > ')
        x = i.split(' ')
        print(x)
    
    elif c == "word_counter":
        i = input('Sentence (To count words): \n > ')
        x = i.split(' ')
        print(len(x))

    elif c=="gen_ln_plot":
            x_values = []
            y_values = []

            l= input('Name: ')
            num_points = int(input("Enter the number of data points for the line plot: "))

            for i in range(num_points):
                x = float(input(f"Enter x-coordinate for point {i + 1}: "))
                y = float(input(f"Enter y-coordinate for point {i + 1}: "))
                x_values.append(x)
                y_values.append(y)

            plt.figure(figsize=(8, 6))
            plt.plot(x_values, y_values, marker='o', linestyle='-', color='blue')
            plt.title(l)
            plt.xlabel('X-axis')
            plt.ylabel('Y-axis')
            plt.grid(True)
            plt.show()

    elif c == "color_set":
        color_settings()
    elif c == "readJSON":
        user_input = input('JSON Input (Straight Line): \n > ')
    
        try:
            # Assuming the input is a valid JSON string
            data = jx.loads(user_input)
        except jx.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return
    
        for key, value in data.items():
            print(f"Key: {key}, Value: {value}")
    elif c == "webScrape":
        scrape_website()
    elif c == "yolo_detect8m":
        print('Q to quit program.')
        print('Requires installation... Will install automatically. DO NOT DELETE THE FILE, it is a local version (no internet) Neural Network.')
        model = YOLO("yolov8m.pt")
        camera_index = 0
        cap = cv2.VideoCapture(camera_index)

        while cap.isOpened():
            # Read a frame from the camera
            ret, frame = cap.read()

            if not ret:
                print('Error: RET is not working (camera is not working or sending a valid response). Try another camera.')
                break

            # Convert the frame to the format expected by YOLOv8
            yolo_input = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Make a prediction using YOLOv8
            results = model.predict(yolo_input)

            # Get the first set of results
            result = results[0]

            # Display the frame with YOLOv8 results
            for box in result.boxes:
                class_id = result.names[box.cls[0].item()]
                cords = box.xyxy[0].tolist()
                cords = [round(x) for x in cords]
                conf = round(box.conf[0].item(), 2)
            

                # Draw a bounding box and label on the frame
                cv2.rectangle(frame, (cords[0], cords[1]), (cords[2], cords[3]), (0, 0, 255), 2)
                label = f"Object type: {class_id}\nCoordinates: {cords}\nProbability: {conf} "

                cv2.putText(frame, label, (cords[0], cords[1] - 20),
                            cv2.FONT_HERSHEY_DUPLEX, 0.5, (0, 0, 255), 2)

            # Display the frame with bounding boxes and labels
            cv2.imshow("YOLOv8 Results", frame)

            # Break the loop if the user presses 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                return
            

        # Release the camera and close all OpenCV windows
        cap.release()
        cv2.destroyAllWindows()

        


        
    else:
        print(f'Unkown Command {s}: \n Not in the list of avaliable functions, please try a different command.')
    
text_color = Fore.WHITE
background_color = Back.RESET
text_brightness = Style.RESET_ALL

def color_settings():
    global text_color, background_color, text_brightness  # Declare global variables

    init()

    print('Settings:')
    print("Capital Sensitive")
    print('1. Quit')
    print('2. Set Text Color')
    print('3. Set Background Color')
    print('4. Set Text Brightness')
    print('5. Reset All')

    i = input('Choose a number: \n> ')

    if i == '1':
        return
    elif i == '2':
        text_color_input = input('Choose a color (for text, Uses BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET): ')
        if text_color_input in ['BLACK', 'RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'RESET']:
            text_color = getattr(Fore, text_color_input)
        else:
            print('Invalid color selection for text.')
    elif i == '3':
        background_color_input = input('Choose a color (for background, Uses BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET): ')
        if background_color_input in ['BLACK', 'RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'RESET']:
            background_color = getattr(Back, background_color_input)
        else:
            print('Invalid color selection for background.')
    elif i == '4':
        brightness_input = input('Text Brightness (Use BRIGHT or DIM): \n> ')
        if brightness_input in ['BRIGHT', 'DIM']:
            text_brightness = getattr(Style, brightness_input)
        else:
            print('Invalid brightness option.')
    elif i == '5':
        text_color = Fore.RESET  # Resetting text color to default
        background_color = Back.RESET  # Resetting background color to default
        text_brightness = Style.RESET_ALL  # Resetting text brightness to default
        print('Settings reset to default.')
    else:
        print("Invalid option. Please choose a valid number.")

    # Output with selected settings
    combined_style = f"{text_brightness}{text_color}{background_color}"
    print(f"{combined_style}Sample Text")
while True:
    # DO NOT DELETE THIS CODE. This runs the program.
    s = str(askAndCompute())
    detect(s)
    pass
#?██████╗ ██╗   ██╗████████╗███████╗██████╗ ███╗   ███╗██╗███╗   ██╗ █████╗ ██╗         ██████╗ ██████╗  ██████╗ 
#?██╔══██╗╚██╗ ██╔╝╚══██╔══╝██╔════╝██╔══██╗████╗ ████║██║████╗  ██║██╔══██╗██║         ██╔══██╗██╔══██╗██╔═══██╗
#?██████╔╝ ╚████╔╝    ██║   █████╗  ██████╔╝██╔████╔██║██║██╔██╗ ██║███████║██║         ██████╔╝██████╔╝██║   ██║
#?██╔═══╝   ╚██╔╝     ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║██║██║╚██╗██║██╔══██║██║         ██╔═══╝ ██╔══██╗██║   ██║
#?██║        ██║      ██║   ███████╗██║  ██║██║ ╚═╝ ██║██║██║ ╚████║██║  ██║███████╗    ██║     ██║  ██║╚██████╔╝
#?╚═╝        ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝ 
#*  ▄▄▄▄▄▄▄▄▄▄▄  ▄         ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄       ▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄        ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄                 ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ 
#*▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░░▌      ▐░▌▐░░░░░░░░░░░▌▐░▌               ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
#*▐░█▀▀▀▀▀▀▀█░▌▐░▌       ▐░▌ ▀▀▀▀█░█▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░▌░▌   ▐░▐░▌ ▀▀▀▀█░█▀▀▀▀ ▐░▌░▌     ▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌               ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌
#*▐░▌       ▐░▌▐░▌       ▐░▌     ▐░▌     ▐░▌          ▐░▌       ▐░▌▐░▌▐░▌ ▐░▌▐░▌     ▐░▌     ▐░▌▐░▌    ▐░▌▐░▌       ▐░▌▐░▌               ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌
#*▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌     ▐░▌     ▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄█░▌▐░▌ ▐░▐░▌ ▐░▌     ▐░▌     ▐░▌ ▐░▌   ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌               ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌
#*▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌     ▐░▌     ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌  ▐░▌  ▐░▌     ▐░▌     ▐░▌  ▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░▌               ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌
#!▐░█▀▀▀▀▀▀▀▀▀  ▀▀▀▀█░█▀▀▀▀      ▐░▌     ▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀█░█▀▀ ▐░▌   ▀   ▐░▌     ▐░▌     ▐░▌   ▐░▌ ▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌               ▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀█░█▀▀ ▐░▌       ▐░▌
#!▐░▌               ▐░▌          ▐░▌     ▐░▌          ▐░▌     ▐░▌  ▐░▌       ▐░▌     ▐░▌     ▐░▌    ▐░▌▐░▌▐░▌       ▐░▌▐░▌               ▐░▌          ▐░▌     ▐░▌  ▐░▌       ▐░▌
#!▐░▌               ▐░▌          ▐░▌     ▐░█▄▄▄▄▄▄▄▄▄ ▐░▌      ▐░▌ ▐░▌       ▐░▌ ▄▄▄▄█░█▄▄▄▄ ▐░▌     ▐░▐░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄▄▄      ▐░▌          ▐░▌      ▐░▌ ▐░█▄▄▄▄▄▄▄█░▌
#!▐░▌               ▐░▌          ▐░▌     ▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌      ▐░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌     ▐░▌          ▐░▌       ▐░▌▐░░░░░░░░░░░▌
#! ▀                 ▀            ▀       ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀        ▀▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀       ▀            ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀ 
#
                                                                                                           
#????                         I8                                                                          ,dPYb,
#????                         I8                                                                          IP'`Yb
#!!!!                      88888888                                        gg                             I8  8I
#!!!!                         I8                                           ""                             I8  8'
#**** gg,gggg,    gg     gg   I8    ,ggg,    ,gggggg,   ,ggg,,ggg,,ggg,    gg    ,ggg,,ggg,     ,gggg,gg  I8 dP 
#**** I8P"  "Yb   I8     8I   I8   i8" "8i   dP""""8I  ,8" "8P" "8P" "8,   88   ,8" "8P" "8,   dP"  "Y8I  I8dP  
#!!!! I8'    ,8i  I8,   ,8I  ,I8,  I8, ,8I  ,8'    8I  I8   8I   8I   8I   88   I8   8I   8I  i8'    ,8I  I8P   
#todoI8 _  ,d8' ,d8b, ,d8I ,d88b, `YbadP' ,dP     Y8,,dP   8I   8I   Yb,_,88,_,dP   8I   Yb,,d8,   ,d8b,,d8b,_ 
#todoPI8 YY88888PP""Y88P"8888P""Y8888P"Y8888P      `Y88P'   8I   8I   `Y88P""Y88P'   8I   `Y8P"Y8888P"`Y88P'"Y88
#todo I8               ,d8I'                                                                                    
#todo I8             ,dP'8I                                                                                     
#!!!! I8            ,8"  8I                                                                                     
#?? I8            I8   8I                                                                                     
#?? I8            `8, ,8I                                                                                     
#!! I8             `Y8P"         
                                                                                                           
                                                                            



