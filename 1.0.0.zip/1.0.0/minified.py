_L='strInstructions'
_K='Instructions: '
_J='strCategory'
_I='Category: '
_H='strMeal'
_G='region'
_F='decode'
_E='meals'
_D='encode'
_C=None
_B='clear'
_A='N/A'
import http.server,socketserver,threading,time,sys,wave,getpass,random
from io import BytesIO
from http.server import SimpleHTTPRequestHandler
def loading_screen():
	animation='ABCDEFGHIJKLMNOPQRSTUVWXYZ$@B%8&WM#*/\\|()1{}[]?-_+~<>i!lI;:,"^`\'.';index=0;num_loops=10;repeat=random.randint(5,10)
	for _ in range(num_loops):
		for _ in range(repeat):random1=random.randint(1,10);random2=random.randint(1,10);random3=random.randint(1,10);random4=random.randint(1,10);random5=random.randint(1,10);index=(index+random1)%len(animation);index2=(index+random2)%len(animation);index3=(index+random3)%len(animation);index4=(index+random4)%len(animation);index5=(index+random5)%len(animation);sys.stdout.write(f"\rLoading {animation[index]}{animation[index2]}{animation[index3]}{animation[index4]}{animation[index5]} ");sys.stdout.flush();time.sleep(.1)
		sys.stdout.write('\r')
loading_screen()
server_running=False
httpd=_C
custom_html=_C
def start_server():
	global server_running,httpd
	if not server_running:Handler=MyHandler;PORT=int(input('Enter port: '));server_address='',PORT;httpd=socketserver.ThreadingTCPServer(server_address,Handler);server_thread=threading.Thread(target=httpd.serve_forever);server_thread.start();server_running=True;print('Server Running on Port {}'.format(PORT))
def stop_server():
	global server_running,httpd
	if server_running:httpd.shutdown();httpd.server_close();server_running=False;print('Server Stopped')
class MyHandler(SimpleHTTPRequestHandler):
	def do_GET(self):
		self.send_response(200);self.send_header('Content-type','text/html');self.end_headers()
		if custom_html:self.wfile.write(custom_html.encode())
		else:self.wfile.write('No HTML file was sent for this purpose. To stop this program, press stop localhost and then import a new file, otherwise it will break.'.encode())
	def log_message(self,format,*args):log_message='[%s] %s\n'%(self.log_date_time_string(),format%args);print(log_message)
	def do_POST(self):content_length=int(self.headers['Content-Length']);post_data=self.rfile.read(content_length);print('Received:',post_data);self.send_response(200);self.end_headers();response=BytesIO();response.write(b'getPostRequest');response.write(b'Received: ');response.write(post_data);print('Received Information from localhost Using: POST, received: '+str(post_data))
def open_custom_html():
	global custom_html;file_path=input('Enter the path to the HTML file: ')
	if file_path:
		with open(file_path,'r')as file:custom_html=file.read()
		print('Custom HTML file loaded: {}'.format(file_path))
def main():
	print('1. Start Server');print('2. Stop Server');print('3. Load Custom HTML');print('4. Quit Program');choice=input('Enter your choice: ')
	if choice=='1':start_server()
	elif choice=='2':stop_server()
	elif choice=='3':open_custom_html()
	elif choice=='4':
		if server_running:stop_server()
		print('Quitting Program')
	else:print('Invalid choice. Please select a valid option.')
def caesar_cipher(text,shift,action=_D):
	result=''
	for char in text:
		if char.isalpha():
			if char.islower():base=ord('a')
			else:base=ord('A')
			if action==_D:result+=chr((ord(char)-base+shift)%26+base)
			elif action==_F:result+=chr((ord(char)-base-shift)%26+base)
		else:result+=char
	return result
import random
def fetch_and_print_country_info():
	H='maps';G='coatOfArms';F='svg';E='png';D='flags';C='common';B='name';A=', '
	try:
		response=requests.get('https://restcountries.com/v3.1/all');response.raise_for_status();data=response.json();print('Select a country to view information:');country_names=[country.get(B,{}).get(C,_A)for country in data]
		for name in country_names:print(name)
		selected_name=input('Enter the name of the country you want to view information for: ');os.system(_B);selected_country=_C
		for country in data:
			commonName=country.get(B,{}).get(C,_A)
			if commonName==selected_name:selected_country=country;break
		if selected_country:commonName=selected_country.get(B,{}).get(C,_A);officialName=selected_country.get(B,{}).get('official',_A);tlds=A.join(selected_country.get('tld',[_A]));alpha2Code=selected_country.get('cca2',_A);alpha3Code=selected_country.get('cca3',_A);currencies=A.join(selected_country.get('currencies',{}).keys())or _A;capitalCities=A.join(selected_country.get('capital',[_A]));region=selected_country.get(_G,_A);subregion=selected_country.get('subregion',_A);languages=A.join(selected_country.get('languages',{}).values())or _A;borders=A.join(selected_country.get('borders',[_A]));area=selected_country.get('area',_A);population=selected_country.get('population',_A);timezones=A.join(selected_country.get('timezones',[_A]));latlng=selected_country.get('latlng');landlocked=selected_country.get('landlocked');flagPng=selected_country.get(D,{}).get(E,'');flagSvg=selected_country.get(D,{}).get(F,'');flagAlt=selected_country.get(D,{}).get('alt','Flag information not available');coatOfArmsPNG=selected_country.get(G,{}).get(E,'');coatOfArmsSVG=selected_country.get(G,{}).get(F,'');maps=selected_country.get(H,{}).get('googleMaps',_A);maps2=selected_country.get(H,{}).get('openStreetMaps',_A);isIndependent=selected_country.get('independent');isUnitedNationsMember=selected_country.get('unMember');os.system(_B);print('Country Information:');print(f"Common Name: {commonName}");print(f"Official Name: {officialName}");print(f"TLDs: {tlds}");print(f"Alpha-2 Code: {alpha2Code}");print(f"Alpha-3 Code: {alpha3Code}");print(f"Currencies: {currencies}");print(f"Capital Cities: {capitalCities}");print(f"Region: {region}");print(f"Subregion: {subregion}");print(f"Languages: {languages}");print(f"Borders: {borders}");print(f"Area: {area} sq km");print(f"Population: {population}");print(f"Timezones: {timezones}");print(f"Latitude and Longitude: {latlng}");print(f"Is United Nations Member (Not including non-member observers): {isUnitedNationsMember}");print(f"Independent: {isIndependent}");print(f"Landlocked: {landlocked}");print(f"Maps Link (Google Maps): {maps}");print(f"Maps Link (Open Street Maps): {maps2}");print('\nFlag:');print(f"Flag PNG: {flagPng}");print(f"Flag SVG: {flagSvg}");print('Flag Alt: '+flagAlt);print('\nCoat Of Arms:');print(f"Coat Of Arms PNG: {coatOfArmsPNG}");print(f"Coat Of Arms SVG: {coatOfArmsSVG}")
		else:print('Country not found.')
	except requests.exceptions.RequestException as e:print(f"Failed to fetch country data from the API: {e}")
from googletrans import Translator
translatorObject=Translator()
root=_C
todo_list=[]
import urllib.parse,tkinter,webbrowser
from colorama import Fore
import requests,os,subprocess,platform
todo_list=[]
def add_task(task):todo_list.append(task)
def list_tasks():
	for(i,task)in enumerate(todo_list,start=1):print(f"{i}. {task}")
def remove_task(task_index):
	if 1<=task_index<=len(todo_list):del todo_list[task_index-1]
	else:print('Invalid task index')
def password_strength(password):
	length_ok=len(password)>=8;contains_lowercase=any(char.islower()for char in password);contains_uppercase=any(char.isupper()for char in password);contains_digit=any(char.isdigit()for char in password);contains_special=any(char in'!@#$%^&*()-_=+[]{}|;:\'",.<>?/'for char in password)
	if length_ok and contains_lowercase and contains_uppercase and contains_digit and contains_special:return'Strong'
	elif length_ok and(contains_lowercase or contains_uppercase)and contains_digit:return'Moderate'
	else:return'Weak'
import time,math,urllib.request,os,webbrowser,platform,hashlib,random,getpass as g,string,json
print('Finished Loading! Thank you for using PyTerminal')
time.sleep(5)
os.system(_B)
def search_recipe(search_term):
	url='https://www.themealdb.com/api/json/v1/1/search.php';params={'s':search_term};response=requests.get(url,params=params)
	if response.status_code==200:
		data=response.json()
		if data[_E]is not _C:
			for meal in data[_E]:
				print('Recipe Name: '+meal[_H]);print(_I+meal[_J]);print(_K+meal[_L]);print('Ingredients:')
				for i in range(1,21):
					ingredient=meal.get(f"strIngredient{i}");measure=meal.get(f"strMeasure{i}")
					if ingredient and measure:print(f"{measure.strip()} {ingredient.strip()}")
				print('\n')
		else:print('No recipes found for your search term.')
	else:print('Failed to retrieve data from the API.')
def download_page(url,save_file_name):
	try:
		responsexmc=urllib.request.urlopen(url);html_content=responsexmc.read().decode('utf-8')
		with open(save_file_name,'w')as file:file.write(html_content)
	except urllib.error.URLError:print(f"Unable to download webpage from {url}.")
def askAndCompute():inx=input(' > ');return inx
def comfigure(c):
	W='type';V='Shift: \n > ';U='No notes found.';T='notes.txt';S='Input text:\n > ';R='WHITE';Q='CYAN';P='MAGENTA';O='BLUE';N='YELLOW';M='GREEN';L='RED';K='BLACK';J='Input Text:';I='iss_position';H='link';G='title';F='year';E='Events';D='text';C='data';B='> ';A='links'
	if c=='version':print('1.0.0 SUPER TERMINAL')
	elif c=='time':x=time.asctime();print(x)
	elif c.startswith('runPyFunction'):
		inputx=c[len('runPyFunction '):]
		try:exec(inputx)
		except Exception as e:print(f"Error: {e}")
	elif c=='calculator':
		expression=input('Enter a mathematical expression: ')
		try:result=eval(expression);print(f"Result: {result}")
		except Exception as e:print(f"Error: {e}")
	elif c=='CTF':i=input('Input Celsius: ');l=float(i)*9/5+32;print(l)
	elif c=='FTC':n=input('Farenheit INPUT: ');l=float(n)-32*9/5;print(l)
	elif c=='ran':print('Must be integer');l=int(input('MAX: '));lx=int(input('MIN: '));print(random.randint(l,lx))
	elif c=='sys_info':print('System Information:');print(f"Operating System: {platform.system()} {platform.release()}");print(f"Machine: {platform.machine()}");print(f"Processor: {platform.processor()}");print(f"Python Version: {platform.python_version()}");print(f"Current Directory: {os.getcwd()}")
	elif c=='redir':l=input('Enter Query: ');webbrowser.open('https://www.google.com/search?q='+l)
	elif c=='list_file':
		files=os.listdir()
		for file in files:print(file)
	elif c=='gen_pas':length=int(input('Input LENGTH OF PASSWORD: '));characters=string.ascii_letters+string.digits+string.punctuation;password=''.join(random.choice(characters)for _ in range(length));print(password)
	elif c=='//division':x=int(input('First INP: '));z=int(input('Second INP: '));print(x//z)
	elif c=='TIMER':
		r=int(input('Seconds :'))
		for remaning in range(r,0,-1):minutes,seconds=divmod(remaning,60);print(f"Time Remaining: {minutes:02d}: {seconds:02d}",end='\r');time.sleep(1)
		print('Complete!                              ')
	elif c=='SHA256HASH':i=input('Input Value: ');has_obj=hashlib.new('sha256');has_obj.update(i.encode());hash_value=has_obj.hexdigest();print(f"RESULT! {hash_value}")
	elif c=='quitProgram':quit()
	elif c=='password_strength':lxbv=getpass.getpass('Password to check: ');password_strength_2=password_strength(lxbv);print(f"Password strength {password_strength_2}")
	elif c=='list_tasks':
		for(i,task)in enumerate(todo_list,start=1):print(f"{i}. {task}")
	elif c=='remove_tasks':list_tasks();xMx=int(input('Task to remove (Give a number):'));remove_task(xMx)
	elif c=='add_tasks':zmxc=input('Name Of Task : \n');add_task(zmxc)
	elif c=='weatherwttr':
		nate=input('Request Location: \n > ');city=urllib.parse.quote(nate);lang='en'
		def fetch_data(url,label):
			try:
				response=requests.get(url)
				if response.status_code==200:data=response.text;print(f"{label}: {data}")
				else:print(f"Failed to fetch {label} data.")
			except Exception as e:print(f"Failed to fetch {label} data.")
		def fetchCondition():url=f"https://wttr.in/{city}?format=%C&lang={lang}";fetch_data(url,'Condition')
		def fetchTemperature():url=f"https://wttr.in/{city}?format=%t&lang={lang}";fetch_data(url,'Temperature')
		def fetchHumidity():url=f"https://wttr.in/{city}?format=%h&lang={lang}";fetch_data(url,'Humidity')
		def fetchWind():url=f"https://wttr.in/{city}?format=%w&lang={lang}";fetch_data(url,'Wind')
		def fetchPrecipitation():url=f"https://wttr.in/{city}?format=%f&lang={lang}";fetch_data(url,'Precipitation')
		def fetchPressure():url=f"httpswttr.in/{city}?format=%P&lang={lang}";fetch_data(url,'Pressure')
		def fetchSunrise():url=f"https://wttr.in/{city}?format=%S&lang={lang}";fetch_data(url,'Sunrise')
		def fetchSunset():url=f"https://wttr.in/{city}?format=%s&lang={lang}";fetch_data(url,'Sunset')
		def fetchUV():url=f"https://wttr.in/{city}?format=%u&lang={lang}";fetch_data(url,'UV')
		def fetchfeelslike():url=f"https://wttr.in/{city}?format=%f&lang={lang}";fetch_data(url,'Feels Like (Temperature)')
		fetchCondition();fetchTemperature();fetchHumidity();fetchWind();fetchPrecipitation();fetchPressure();fetchSunrise();fetchSunset();fetchUV();fetchfeelslike()
	elif c=='iss_location':requete=requests.get('http://api.open-notify.org/iss-now.json');x=requete.json();print('Response:');longitude=x[I]['longitude'];print('Longitude: '+longitude);latitude=x[I]['latitude'];print('Latitude: '+latitude)
	elif c=='joke_generator':
		requedx=requests.get('https://riddles-api.vercel.app/random');req=requedx.json();joke=req['riddle'];answer=req['answer'];print('Joke: '+joke);insert=input('input ans to complete (Case-sensitive), or type "quit" to end: \n > ')
		if insert=='ans':print('Answer: '+answer)
		if insert=='quit':return
	elif c=='setColor':
		print('Colors Avaliable to use (case-sensitive) BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE.');inputx=input(B);text=input(J)
		if inputx==K:print(Fore.BLACK+text);print(Fore.RESET+'')
		if inputx==L:print(Fore.RED+text);print(Fore.RESET+'')
		if inputx==M:print(Fore.GREEN+text);print(Fore.RESET+'')
		if inputx==N:print(Fore.YELLOW+text);print(Fore.RESET+'')
		if inputx==O:print(Fore.BLUE+text);print(Fore.RESET+'')
		if inputx==P:print(Fore.MAGENTA+text);print(Fore.RESET+'')
		if inputx==Q:print(Fore.CYAN+text);print(Fore.RESET+'')
		if inputx==R:print(Fore.WHITE+text);print(Fore.RESET+'')
	elif c=='setDefaultColor':
		print('Colors Avaliable to use (case-sensitive) BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, And RESET.');inputx=input(B);text=input(J)
		if inputx==K:print(Fore.BLACK+text)
		if inputx==L:print(Fore.RED+text)
		if inputx==M:print(Fore.GREEN+text)
		if inputx==N:print(Fore.YELLOW+text)
		if inputx==O:print(Fore.BLUE+text)
		if inputx==P:print(Fore.MAGENTA+text)
		if inputx==Q:print(Fore.CYAN+text)
		if inputx==R:print(Fore.WHITE+text)
		if inputx=='RESET':print(Fore.RESET+'')
	elif c=='googletrans':textToTranslate=input(S);toLanguageCode=input('Input Destination Language Code:\n > ');detected_language=translatorObject.detect(textToTranslate).lang;result=translatorObject.translate(textToTranslate,dest=toLanguageCode,src=detected_language);print('Translated text:',result.text);print('Source language:',result.src);print('Destination language:',toLanguageCode)
	elif c=='webbrow_search':inx=input('HTTP: ');webbrowser.open(inx)
	elif c=='detectLang':textx=input(S);x=translatorObject.detect(textx).lang;print('Detected Language: '+str(x))
	elif c=='gtn':
		m=random.randint(1,100);print('Guess the number!');ans=input(B)
		while True:
			ans=int(input(B))
			if ans!=m:
				if ans>m:print('Lower!')
				if ans<m:print('Higher')
			else:
				if ans==m:print('Correct!');break
				break
	elif c=='noteManager':
		xcm=input('Choose an option:\n1. View Notes\n2. Create Notes\n')
		if xcm=='1':
			try:
				with open(T,'r')as file:
					notes=file.read()
					if notes:print('Your notes:\n');print(notes)
					else:print(U)
			except FileNotFoundError:print(U)
		elif xcm=='2':
			title=input('Enter a title for your note: ');content=input('Enter the content of your note: ')
			with open(T,'a')as file:file.write(f"Title: {title}\nContent: {content}\n\n")
			print('Note saved successfully.')
	elif c=='country':fetch_and_print_country_info()
	elif c==_B:os.system(_B)
	elif c=='caesar_cipher_enc':print(caesar_cipher(str(input('Text: \n > ')),int(input(V)),action=_D))
	elif c=='caesar_cipher_dec':print(caesar_cipher(str(input('Decode Text: \n > ')),int(input(V)),action=_F))
	elif c=='':os.system(_B)
	elif c=='ipnetwork':
		try:response=requests.get('https://ipapi.co/json');response.raise_for_status();data=response.json();ipx=data.get('ip',_A);network=data.get('network',_A);region=data.get(_G,_A);print('IP: '+ipx+'\nNetwork: '+network+'\nRegion: '+region)
		except requests.exceptions.RequestException as e:print('Failed to fetch IP information:',e)
	elif c=='themealsearch':dx=input('meal search: \n > ');search_recipe(dx)
	elif c=='manualFetch':manualFetchLink=input('Fetch Link: \n > ');xm=requests.get(manualFetchLink);jsonManualFetch=xm.json();print('Manual JSON: '+str(jsonManualFetch))
	elif c=='localhost':print('Please first load a custom html.');main()
	elif c=='refresh':loading_screen();os.system(_B)
	elif c=='randomFood':urlForTheMealDB='https://www.themealdb.com/api/json/v1/1/random.php';x=requests.get(urlForTheMealDB);z=x.json();mealInfo=z[_E][0];mealStr=mealInfo[_H];category=mealInfo[_J];instructions=mealInfo[_L];area=mealInfo['strArea'];mealThumb=mealInfo['strMealThumb'];mealSource=mealInfo['strSource'];mealYoutube=mealInfo['strYoutube'];print('Meal: '+str(mealStr));print(_I+str(category));print(_K+str(instructions));print('Area Created: '+str(area));print('Meal Thumbnail: '+str(mealThumb));print('Meal Source: '+str(mealSource));print('YouTube Link: '+str(mealYoutube))
	elif c=='searchHistory':
		month=input('Enter the month: ');day=input('Enter the day: ');keyword=input('Enter the keyword: ').strip();api_url=f"https://history.muffinlabs.com/date/{month}/{day}";response=requests.get(api_url);data=response.json()
		if not data.get(C)or not data[C].get(E)or len(data[C][E])==0:print('No events found for the given date and keyword.');return
		events=[event for event in data[C][E]if keyword.lower()in event[D].lower()];births=[event for event in events if event.get(W)=='birth'];deaths=[event for event in events if event.get(W)=='death']
		if not events and not births and not deaths:print('No matching events, births, or deaths found for the given keyword.')
		if events:
			print('Events:')
			for event in events:
				print(f"{event[F]}: {event[D]}")
				if event.get(A):
					for link in event[A]:print(f"  - {link[G]}: {link[H]}")
		if births:
			print('Births:')
			for event in births:
				print(f"{event[F]}: {event[D]}")
				if event.get(A):
					for link in event[A]:print(f"  - {link[G]}: {link[H]}")
		if deaths:
			print('Deaths:')
			for event in deaths:
				print(f"{event[F]}: {event[D]}")
				if event.get(A):
					for link in event[A]:print(f"  - {link[G]}: {link[H]}")
	else:print('Invalid command')
while True:s=askAndCompute();comfigure(s)