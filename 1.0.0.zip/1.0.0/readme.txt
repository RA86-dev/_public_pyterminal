1.0 is the base update module. The Functions are listed below.
pip install request
pip install colorama
pip install googletrans

After typing all the commands,
Congrats! The codes are listed below along with the file to download.

Functions:

* version: Displays the version of the PyTerminal.
* time: Displays the current system time.
* runPyFunction <Python code>: Allows you to execute Python code within the script.
* calculator: Opens a calculator to perform mathematical calculations.
* CTF: Converts Celsius to Fahrenheit.
* FTC: Converts Fahrenheit to Celsius.
* ran: Generates a random integer within a specified range.
* sys_info: Displays system information.
* redir: Redirects to a Google search based on your query.
* list_file: Lists files in the current directory.
* gen_pas: Generates a random password.
* //division: Performs integer division.
* TIMER: Sets a timer for a specified number of seconds.
* SHA256HASH: Computes the SHA-256 hash of a value.
* quitProgram: Quits the program.
* password_strength: Checks the strength of a password.
* list_tasks: Lists tasks in a to-do list.
* remove_tasks: Removes a task from the to-do list.
* add_tasks: Adds a task to the to-do list.
* weatherwttr: Retrieves and displays weather information.
* iss_location: Retrieves and displays the current International Space Station (ISS) location.
* joke_generator: Generates and displays a joke.
* setColor: Sets the color of text output (requires the colorama library).
* setDefaultColor: Resets text color to default.
* googletrans: Translates text to another language (requires the googletrans library).
* webbrow_search: Opens a web browser with a specified URL.
* detectLang: Detects the language of a given text.
* gtn: Plays a number-guessing game.
* noteManager: Manages notes, including viewing and creating them.
* country: Fetches and prints information about a selected country.
* clear: Clears the terminal screen.
* caesar_cipher_enc: Encrypts text using the Caesar cipher.
* caesar_cipher_dec: Decrypts text using the Caesar cipher.
* ipnetwork: Retrieves and displays information about your IP address and network.
* themealsearch: Searches for recipes based on a query.
* manualFetch: Fetches a custom result for the user.
* localhost: Allows you to create a localhost, use localhost:<PORT> for accessing. Use the entire directory.
* refresh: Refreshes the code.
* randomFood: Obtains a random food from a huge library.
* searchHistory: Obtains a keyword (required), date.
